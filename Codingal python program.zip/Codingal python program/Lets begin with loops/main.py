# Lesson 1 - nested conditional statements

# Activity 1 - ask the user whether he is medically fit to take exam. if yes then print that he is allowed to take the exam. if not then ask his attendance percentage. if percentage is greater then equal to 75 then he is allowed otherwise not

